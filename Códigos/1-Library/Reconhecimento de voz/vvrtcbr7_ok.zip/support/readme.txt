IBM ViaVoice Speech Suport 
Copyright 1999 All Rights Reserved
------

This installation is to correct known problems when installing IBM ViaVoice Pro,
IBM ViaVoice Web, or IBM ViaVoice Standard over newer speech enabled applications.
If you have installed ViaVoice Pro and are experiencing trouble with applications 
which use IBM Speech Support, run the 'repairrt.exe' to fix possibly corrupted files.

If, after running �repairrt.exe�, your speech application still does not work, 
contact the application provider.


Note: repairrt.exe should be invoked after all applications using IBM Speech Support
      have been terminated and the system has been idle for 1 minute.







