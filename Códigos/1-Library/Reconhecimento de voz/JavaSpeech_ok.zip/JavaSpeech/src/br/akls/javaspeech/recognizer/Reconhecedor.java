/*
 * Created on 10/05/2005
 *  
 */
package br.akls.javaspeech.recognizer;

import java.util.Locale;

import javax.speech.Central;
import javax.speech.EngineModeDesc;
import javax.speech.recognition.Recognizer;
import javax.speech.recognition.Result;
import javax.speech.recognition.ResultAdapter;
import javax.speech.recognition.ResultEvent;
import javax.speech.recognition.ResultToken;
import javax.speech.recognition.RuleGrammar;

public class Reconhecedor extends ResultAdapter {
	public static Recognizer rec;
	private String url;
	private String gramatica;
	private Command command;

	public Reconhecedor(String url, String gram) {
		this.url = url;
		gramatica = gram;
	}
	
	public void setCommand(Command com) {
		command = com;
	}
	
	public Command getCommand() {
		return command;
	}

	// Receives RESULT_ACCEPTED event: print it, clean up, exit
	public void resultAccepted(ResultEvent e) {
		Result r = (Result) (e.getSource());
		ResultToken tokens[] = r.getBestTokens();
		String frase = "";
		for (int i = 0; i < tokens.length; i++) {
			frase = frase.concat(tokens[i].getSpokenText() + " ");
		}
		System.out.println(frase + ".");
		if(command!=null)
			command.commandSaid(frase);
		//Sintetizador sin = new Sintetizador();
		//sin.speak(frase);
		// Deallocate the recognizer and exit
		if ((tokens[0].getSpokenText()).equals("terminar")) {
			try {
				rec.deallocate();
				System.out.println("SAINDO DO PROGRAMA");
				System.exit(0);
			} catch (Exception exp) {
				System.out.println("Deu pau! " + exp.toString());
			}
		}
	}

	public void iniciar() {
		try {
			// Create a recognizer that supports Portuguese.
			rec = Central.createRecognizer(new EngineModeDesc(new Locale("pt",
					"BR")));
			System.out.println("passou 1: " + rec);
			// Start up the recognizer
			rec.allocate();
			System.out.println("passou 2:");
			// Load the grammar from a file, and enable it
			//FileReader reader = new FileReader("lib\\gramatica.gram");
            //RuleGrammar gram = rec.loadJSGF(reader);
			RuleGrammar gram = rec.loadJSGF(new	java.net.URL(url),gramatica);
			gram.setEnabled(true);
			System.out.println("passou 3:");
			// Add the listener to get results
			rec.addResultListener(this);

			// Commit the grammar
			rec.commitChanges();
			System.out.println("passou 4:");
			// Request focus and start listening
			rec.requestFocus();
			rec.resume();
		} catch (Exception e) {
			System.out.println("Reconhecedor - Error 1: " + e.toString());
			e.printStackTrace();
		}
	}

	public static void main(String args[]) {
		Reconhecedor reconhecedor = new Reconhecedor("http://natalnet.dca.ufrn.br/~aquiles/PerMUD/","gramatica");
		reconhecedor.iniciar();
	}
}

