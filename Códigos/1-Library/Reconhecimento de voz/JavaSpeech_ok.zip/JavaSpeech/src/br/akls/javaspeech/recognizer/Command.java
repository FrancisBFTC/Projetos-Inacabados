/*
 * Created on 25/04/2006
 *
 */
package br.akls.javaspeech.recognizer;

public interface Command {
	
	public void commandSaid(String command);

}
